1. open python-3.6.5  https://www.python.org/downloads/
2. tick "Add Python 3.6 to PATH"
3. click "Install now" and next next next
4. open cmd/powershell as administrator ( press Windows + X and A )
5. navigate to noopapildai directory (example: cd C:\Users\username\Desktop\noopapildai)
6. copy and run this command in cmd ( pip install -r requirements.txt )
7. open noopapildai_spider.py (noopapildai\noopapildai\spiders)
8. xml will be exported in the same directory as noopapildai_spider.py