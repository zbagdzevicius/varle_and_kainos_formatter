USER_AGENT = 'Mozilla/5.0'
FEED_FORMAT = 'xml'

FEED_EXPORTERS = {
    'xml': 'noopapildai.exporters.exporters.MyXmlExportPipeline'
}